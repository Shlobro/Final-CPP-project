#pragma once
#include "Common.h"

class DrawThread
{
public:
	void operator()(Common& common);
	//void DrawAppWindow();
};

